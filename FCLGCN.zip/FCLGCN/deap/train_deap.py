import matplotlib.pyplot as plt
import os
from layers import contrastive_loss
from sklearn.model_selection import KFold
import numpy as np
import torch
from torch import nn
from layers.set_logger import set_logger
import logging
from data.deap_process import DeapDataset
from layers.FCLGCN import FCLGCN


device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
# device = torch.device('cpu')
loss_fn = nn.CrossEntropyLoss().to(device)
contrastiveLoss = contrastive_loss.SupConLoss(temperature=0.1).to(device)

model_dir = '../model/deap/withoutCL'
if not os.path.exists(model_dir):
    os.mkdir(model_dir)

img_dir = '../imgs/deap/withoutCL'
if not os.path.exists(img_dir):
    os.mkdir(img_dir)

seeds = range(0, 1)
for seed in seeds:
    model_seed_dir = model_dir + '/' + f'seed{seed}'
    if not os.path.exists(model_seed_dir):
        os.mkdir(model_seed_dir)

    img_seed_dir = img_dir + '/' + f'seed{seed}'
    if not os.path.exists(img_seed_dir):
        os.mkdir(img_seed_dir)

label_types = ['valence', 'arousal', 'dominance']
params = {
    'T': 5,
    'batch_size': 32,
    'max_iteration': 5000,  # maximum number of iterations
    'k_fold': 5,
    'num_channels':32,
}


def train(model, device, train_data, train_labels, loss_fn, constrastiveLoss, optimizer):
    # print('training...')
    logging.info('training...')

    for data in train_data:
        data.to(device)

    model.to(device)
    model.train()
    batch_size = params['batch_size']

    step = 0
    flag = True
    while flag:
        for i in range(0, len(train_data), batch_size):
            batch = train_data[i: i + batch_size]
            label = train_labels[i: i + batch_size].to(device)

            y_proj, y_pred = model(batch)
            # -----------------contrastive loss-----------------
            # label = label.squeeze(1)
            # import pdb
            # pdb.set_trace()
            # loss1 = constrastiveLoss(y_proj, label) * 0.2
            loss = loss_fn(y_pred, label) #* 0.8
            # loss = loss1 + loss2

            if step % 100 == 0:
                # logging.info(f'step: {step + 100}, Loss: {loss.item()}')
                logging.info('step: {}, Loss: {:.3f}'.format((step + 100), loss.item()))
            if loss < params['e']:
                flag = False
                break

            optimizer.zero_grad()
            loss.backward()
            # torch.autograd.backward([loss1, loss2])
            optimizer.step()

            step += 1
            if step >= params['max_iteration']:
                flag = False
                break
    logging.info('training successfully ended.')
    return model


def validate(model, device, val_data, val_labels):
    # print('validating...')
    logging.info('validating...')
    model.to(device)
    model.eval()

    TP = 0
    TN = 0
    FP = 0
    FN = 0

    with torch.no_grad():
        label_list = []
        features_list1 = []
        features_list2 = []
        for i, data in enumerate(val_data):
            y_1, y_2,_, output = model([data.to(device)])
            result = torch.argmax(output, dim=-1).flatten().item()
            label = val_labels[i]
            label_list.append(label)
            features_list1.append(y_1)
            features_list2.append(y_2)

            if result == 0 and result == label:
                TP += 1
            if result == 0 and result != label:
                FP += 1
            if result == 1 and result == label:
                TN += 1
            if result == 1 and result != label:
                FN += 1

    acc = (TP + TN) / (TP + TN + FP + FN)

    if TP + FP == 0:
        precision = 0
    else:
        precision = TP / (TP + FP)

    if TP + FN == 0:
        recall = 0
    else:
        recall = TP / (TP + FN)

    if precision + recall == 0:
        f_score = 0
    else:
        f_score = 2 * precision * recall / (precision + recall)

    logging.info(f'acc: {acc}')
    logging.info(f'precision: {precision}')
    logging.info(f'recall: {recall}')
    logging.info(f'F_score: {f_score}')
    # print(f'acc: {acc}')
    # print(f'precision: {precision}')
    # print(f'recall: {recall}')
    # print(f'F_score: {f_score}')
    y_true = np.array(label_list)
    val_label = torch.tensor(y_true)
    features1 = torch.cat(features_list1, dim=0)
    features2 = torch.cat(features_list2, dim=0)

    return acc, precision, recall, f_score, val_label, features1, features2


def binary_sampling(data, label):
    """
    对二分类数据集进行重采样，保证数据平衡
    """
    num = len(data)  # number of samples

    index_0 = torch.nonzero(label == 0, as_tuple=True)[0]
    num_0 = len(index_0)

    index_1 = torch.nonzero(label == 1, as_tuple=True)[0]
    num_1 = len(index_1)
    logging.info(f'num_0: {num_0}, num_1: {num_1}')
    # print([num_0, num_1])

    if abs(num_0 - num_1) < num * 0.25:
        return data, label
    elif num_0 == 0 or num_1 == 0:
        return data, label
    else:
        selected_index = []
        shorter_index, shorter_num = (index_0, num_0) if num_0 < num_1 else (index_1, num_1)
        longer_index, longer_num = (index_0, num_0) if num_0 > num_1 else (index_1, num_1)
        for i in range(longer_num):
            selected_index.append(longer_index[i])
            selected_index.append(shorter_index[i % shorter_num])

        selected_data = []
        for i in selected_index:
            selected_data.append(data[i])
        selected_label = label[selected_index]
        return selected_data, selected_label


def output_figure(path, acc, f_score, title):
    fig = plt.figure(figsize=(10, 5))
    axes = fig.add_axes([0.1, 0.1, 0.8, 0.8])
    x = np.arange(1, 33, dtype=int)

    axes.plot(x, acc, 'rs-')  # 红色，正方形点，实线
    axes.plot(x, f_score, 'bo--')  # 蓝色，圆点，虚线
    axes.legend(labels=('acc', 'F-score'), loc='lower right', fontsize=16)

    axes.set_ylim(0, 1)
    axes.set_yticks(np.arange(0, 1.1, 0.1))
    axes.set_yticklabels([0, 0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1], fontsize=16)

    axes.set_xticks(x)
    axes.set_xticklabels(x, fontsize=12)
    axes.set_xlabel('subject', fontsize=14)

    axes.set_title(title, fontsize=18)
    axes.grid(True)

    fig.savefig(path)
    fig.show()


def cross_validation(data, labels, seed):
    splits = KFold(n_splits=params['k_fold'], shuffle=True, random_state=seed)

    acc_list = []
    f_score_list = []
    fold_models = []
    features1_list = []
    features2_list = []
    labels_list = []

    for fold, (train_idx, val_idx) in enumerate(splits.split(np.arange(len(data)))):
        # print(f'******fold {fold+1}******')
        logging.info(f'******fold {fold+1}******')
        train_data = []
        for i in train_idx:
            train_data.append(data[i])
        train_labels = labels[train_idx]

        val_data = []
        for i in val_idx:
            val_data.append(data[i])
        val_labels = labels[val_idx]

        train_data, train_labels = binary_sampling(train_data, train_labels)

        model = FCLGCN(K=params['K'], T=params['T'], num_channels=params['num_channels'])
        optimizer = torch.optim.Adam(model.parameters(), lr=params['lr'], weight_decay=params['alpha'])

        trained_model = train(model, device, train_data, train_labels, loss_fn, contrastiveLoss, optimizer)
        fold_models.append(trained_model)
        logging.info('training successfully ended.\n, Begin validate(train)')
        validate(trained_model, device, train_data, train_labels)

        acc, precision, recall, f_score, val_label, features1, features2 = validate(trained_model, device, val_data, val_labels)
        features1_list.append(features1)
        features2_list.append(features2)
        labels_list.append(val_label)
        acc_list.append(acc)
        f_score_list.append(f_score)

    avg_acc = np.array(acc_list).mean()
    avg_f_score = np.array(f_score_list).mean()
    features1_1 = torch.cat(features1_list, dim=0)
    features2_1 = torch.cat(features2_list, dim=0)
    features_label = torch.cat(labels_list, dim=0)
    return fold_models, avg_acc, avg_f_score, features1_1, features2_1, features_label


def subject_dependent_exp():
    logging.info('------------------------------------------------')
    logging.info('|         subject dependent experiment         |')
    logging.info('------------------------------------------------')


    params['K'] = 2
    params['num_cells'] = 30
    params['e'] = 0.1
    params['lr'] = 0.003
    params['alpha'] = 0.0008

    dataset = DeapDataset('/data/DEAP/data_preprocessed_python/')
    avg_acc_list = []
    avg_f_score_list = []

    for i in range(len(label_types)):
        logging.info(f'------------{label_types[i]}------------')

        acc_arrays = []
        f_score_arrays = []

        for seed in seeds:
            acc_list = []
            f_score_list = []

            step = 1
            for data, label in dataset:
            
                logging.info(f'-------seed {seed}, subject {step}-------')
                
                used_label = label[:, i]

                model_path = model_dir  + '/' + f'seed{seed}/model_{step}_{label_types[i]}.pt'
                if os.path.exists(model_path):
                    logging.info('model already exists, loading...')
                    
                    trained_models, acc, f_score,features1_1, features2_1, features_label = torch.load(model_path)
                    
                    logging.info('model loaded.')
                else:
                    trained_models, acc, f_score,features1_1, features2_1, features_label = cross_validation(data, used_label, seed)
                    torch.save([trained_models, acc, f_score,features1_1, features2_1, features_label], model_path)
    
                    logging.info('model trained.')

                acc_list.append(acc)
                f_score_list.append(f_score)
               
                logging.info(f'avg_acc: {acc}, avg_f_score: {f_score}')

                step += 1

            acc_array = np.array(acc_list)
            f_score_array = np.array(f_score_list)
            img_path = img_dir + '/' + f'seed{seed}/dependent_{label_types[i]}.png'
            output_figure(img_path, acc_array, f_score_array, f'{label_types[i]}')

            acc_arrays.append(acc_array)
            f_score_arrays.append(f_score_array)


        avg_acc = sum(acc_arrays) / len(acc_arrays)
        avg_acc_list.append(avg_acc)

        avg_f_score = sum(f_score_arrays) / len(f_score_arrays)
        avg_f_score_list.append(avg_f_score)

        output_figure(f'../imgs/dependent_{label_types[i]}_avg.png', avg_acc, avg_f_score, f'{label_types[i]}_avg')

   
    logging.info('-------------------RESULT-------------------')
    for i in range(3):
        logging.info(f'{label_types[i]}')
        logging.info(f'    acc: {avg_acc_list[i]}')

        logging.info(f'    f-score: {avg_f_score_list[i]}')
        
        logging.info(f'    avg_acc = {np.mean(avg_acc_list[i])}, avg_f_score = {np.mean(avg_f_score_list[i])}')


if __name__ == '__main__':
    set_logger(log_path='./logs/{}.log'.format(model_dir.split('/')[-1]))
    logging.basicConfig(format='%(asctime)s %(message)s', level=logging.INFO)
    subject_dependent_exp()
