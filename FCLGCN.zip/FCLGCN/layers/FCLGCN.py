import torch
from torch import nn
import numpy as np
import torch.nn.functional as F
from torch_geometric.data import Batch
from layers.DGCN import DGCNN
from torch_geometric.nn.norm import BatchNorm
# from data.seed import SEED3Dataset
from layers.attention import MultiHeadAttention
from data.deap_process import DeapDataset


class FCLGCN(nn.Module):
    def __init__(self, K, T, num_channels, num_features):
        super(FCLGCN, self).__init__()
        self.K = K
        self.T = T
        self.num_channels = num_channels
        self.num_features = num_features

        self.convs = nn.ModuleList()
        self.batch_norms = nn.ModuleList()

        for i in range(T):
            self.convs.append(DGCNN(self.num_features, num_channels, K, self.num_features))
            self.batch_norms.append(BatchNorm(self.num_features))

        self.sigmoid1 = nn.Sigmoid()
        self.attention = MultiHeadAttention(num_channels * self.num_features, self.num_features)
        self.gru = nn.GRU(num_channels * self.num_features, num_channels, batch_first=True)
        self.batch_norm1 = nn.BatchNorm1d(self.T)
        self.sigmoid2 = nn.Sigmoid()
        self.linear = nn.Linear(num_channels * self.T, 128)
        self.sigmoid3 = nn.Sigmoid()
        self.projection = nn.Linear(128, 2)
        self.classifier = nn.Linear(num_channels * self.T, 2)

        for param in self.parameters():
            if len(param.shape) < 2:
                nn.init.xavier_uniform_(param.unsqueeze(0))
            else:
                nn.init.xavier_uniform_(param)

    def forward(self, x):
        """
        :param x: list of Batch objects
        """
        batch_size = len(x)
        y_list = []
        adj_list = []
        for i in range(self.T):
            xi = []
            for data in x:
                xi.append(data.get_example(i))
            batch_i = Batch.from_data_list(xi)
            input = batch_i.x.reshape(batch_size, self.num_channels, self.num_features)
            yi, adj = self.convs[i](input)
            yi = yi.reshape(-1, self.num_features)
            yi = self.batch_norms[i](yi)
            y_list.append(yi)
            adj_list.append(adj)
        y = torch.stack(y_list)
        y = self.sigmoid1(y)
        # GRU layer
        yt = y.transpose(0, 1)
        y = torch.reshape(yt, (batch_size, self.T, -1))
        # import pdb; pdb.set_trace()
        y, attention = self.attention(y,y,y)
        y_gru, hiden_state = self.gru(y)
        y_gru_out = self.batch_norm1(y_gru)
        y_gru_out = self.sigmoid2(y_gru_out)
        out = torch.reshape(y_gru_out, (batch_size, -1))
        y_1 = self.linear(out)
        y = F.normalize(y_1, dim=0)
        y = self.sigmoid3(y)
        y_proj = self.projection(y)
        y_proj = F.normalize(y_proj, dim=0)
        y_proj = y_proj.unsqueeze(1)
        y_p = self.classifier(out)
        y_pred = self.sigmoid3(y_p)
        return y_1, y_p, y_proj, y_pred