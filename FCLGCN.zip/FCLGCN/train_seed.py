import matplotlib.pyplot as plt
import os

import pandas as pd
from sklearn.model_selection import KFold
import numpy as np
import torch
from torch import nn

from layers import contrastive_loss
from layers.set_logger import set_logger
import logging
from data.seed import SEED3Dataset
# from lib.DGmodel import GCNTCN
from layers.FCLGCN_SEED import GCNTCN
from sklearn.metrics import confusion_matrix
from sklearn.metrics import accuracy_score, average_precision_score,precision_score,f1_score,recall_score


# CUDA_VISIBLE_DEVICES = '3'
device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
# device = torch.device('cpu')
loss_fn = nn.CrossEntropyLoss().to(device)
contrastiveLoss = contrastive_loss.SupConLoss(temperature=0.1).to(device)

model_dir = './model/seed/Alpha_beta'
if not os.path.exists(model_dir):
    os.mkdir(model_dir)

img_dir = './imgs/seed/Alpha_beta'
if not os.path.exists(img_dir):
    os.mkdir(img_dir)

seeds = range(0, 1)
for seed in seeds:
    model_seed_dir = model_dir + '/' + f'seed{seed}'
    if not os.path.exists(model_seed_dir):
        os.mkdir(model_seed_dir)

    img_seed_dir = img_dir + '/' + f'seed{seed}'
    if not os.path.exists(img_seed_dir):
        os.mkdir(img_seed_dir)

params = {
    'T': 5,
    'batch_size': 32,
    'max_iteration': 5000,  # maximum number of iterations
    'k_fold': 5,
}


def hotEncoder(v):
    ret_vec = torch.zeros(v.shape[0], 2).to(device)
    for s in range(v.shape[0]):
        ret_vec[s][v[s]] = 1
    return ret_vec


def train(model, device, train_data, train_labels, loss_fn, constrastiveLoss, optimizer):
    logging.info('training...')
    for data in train_data:
        data.to(device)

    model.to(device)
    model.train()
    batch_size = params['batch_size']

    step = 0
    flag = True
    while flag:
        for i in range(0, len(train_data), batch_size):
            batch = train_data[i: i + batch_size]
            label = train_labels[i: i + batch_size].to(device)
            # import pdb; pdb.set_trace()
            # label = label.unsqueeze(1)
            # label_vec = hotEncoder(label)

            _,_, y_proj, y_pred = model(batch)
            # _,adj_out, y_proj, y_pred = model(batch)
            # import pdb; pdb.set_trace()
            # -----------------contrastive loss-----------------
            # label = label.squeeze(1)
            # import pdb
            # pdb.set_trace()
            loss1 = constrastiveLoss(y_proj, label) * 0.2
            loss2 = loss_fn(y_pred, label) * 0.8
            loss = loss1 + loss2
            # loss = loss_fn(y_pred, label)

            if step % 100 == 0:
                # logging.info(f'step: {step + 100}, Loss: {loss.item()}')
                logging.info('step: {}, Loss: {:.3f}'.format((step + 100), loss.item()))
            if loss < params['e']:
                flag = False
                break

            optimizer.zero_grad()
            # loss.backward()
            torch.autograd.backward([loss1, loss2])
            optimizer.step()

            step += 1
            if step >= params['max_iteration']:
                flag = False
                break

    logging.info('training successfully ended.')
    return model


def validate(model, device, val_data, val_labels):
    logging.info('validating...')
    model.to(device)
    model.eval()

    # 中性情感, 积极情绪，消极情绪
    Neutral = []
    Positive = []
    Negative = []

    with torch.no_grad():
        output_list = []
        label_list = []
        features = []
        adj_features = []
        for i, data in enumerate(val_data):
            feature, adj_featue, _, output = model([data.to(device)])
            features.append(feature)
            adj_features.append(adj_featue)
            result = torch.argmax(output, dim=-1).flatten().item()
            label = val_labels[i]
            label_list.append(label)
            output_list.append(result)
            # # 计算TP，有多少
            if result == 0 and result == label:
                Neutral.append(result)
            if result == 1 and result == label:
                Positive.append(result)
            if result == 2 and result == label:
                Negative.append(result)

    y_true = np.array(label_list)
    y_pred = np.array(output_list)
    cm = confusion_matrix(y_true, y_pred)
    conf_matrix = pd.DataFrame(cm, index=['Neutral','Positive', 'Negative'],
                                   columns=['Neutral','Positive', 'Negative'])

    acc = (len(Neutral) + len(Positive) + len(Negative))/ len(val_labels)
    precision = precision_score(y_true, y_pred, average='micro')
    recall = recall_score(y_true, y_pred, average='micro')
    f_score = f1_score(y_true, y_pred, average='micro')

    logging.info(f'acc: {acc}')
    logging.info(f'precision: {precision}')
    logging.info(f'recall: {recall}')
    logging.info(f'F_score: {f_score}')
    feature = torch.cat(features, dim=0)
    val_label = torch.tensor(y_true)
    adj_feature = torch.cat(adj_features, dim=0)
    adj_feature = adj_feature.sum(dim=0)

    return acc, precision, recall, f_score, conf_matrix, feature,adj_feature,val_label


def output_figure(path, acc, f_score, title):
    fig = plt.figure(figsize=(10, 5))
    axes = fig.add_axes([0.1, 0.1, 0.8, 0.8])
    x = np.arange(1, 16, dtype=int)

    axes.plot(x, acc, 'rs-')  # 红色，正方形点，实线
    axes.plot(x, f_score, 'bo--')  # 蓝色，圆点，虚线
    axes.legend(labels=('acc', 'F-score'), loc='lower right', fontsize=16)

    axes.set_ylim(0, 1)
    axes.set_yticks(np.arange(0, 1.1, 0.1))
    axes.set_yticklabels([0, 0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1], fontsize=16)

    axes.set_xticks(x)
    axes.set_xticklabels(x, fontsize=12)
    axes.set_xlabel('subject', fontsize=14)

    axes.set_title(title, fontsize=18)
    axes.grid(True)

    fig.savefig(path)
    fig.show()


def cross_validation(data, labels, seed):
    splits = KFold(n_splits=params['k_fold'], shuffle=True, random_state=seed)

    acc_list = []
    f_score_list = []
    cm_list = []
    fold_models = []
    features = []
    labels_list = []
    adj_features =[]


    for fold, (train_idx, val_idx) in enumerate(splits.split(np.arange(len(data)))):
        logging.info(f'******fold {fold+1}******')
        train_data = []
        for i in train_idx:
            train_data.append(data[i])
        train_labels = labels[train_idx]

        val_data = []
        for i in val_idx:
            val_data.append(data[i])
        val_labels = labels[val_idx]

        # train_data, train_labels = binary_sampling(train_data, train_labels)

        # model = ECLGCNN(K=params['K'], T=params['T'], num_cells=params['num_cells'])
        model = GCNTCN(K=params['K'], T=params['T'], num_channels=62,num_features=2)
        optimizer = torch.optim.Adam(model.parameters(), lr=params['lr'], weight_decay=params['alpha'])
        scheduler = torch.optim.lr_scheduler.StepLR(optimizer, step_size=1000, gamma=0.1)
        # optimizer = torch.optim.SGD(model.parameters(), lr=params['lr'], weight_decay=params['alpha'])

        trained_model = train(model, device, train_data, train_labels, loss_fn, contrastiveLoss,  optimizer)
        fold_models.append(trained_model)

        validate(trained_model, device, train_data, train_labels)
        acc, precision, recall, f_score, cm, feature_val,adj_feature, label_val = validate(trained_model, device, val_data, val_labels)
        features.append(feature_val)
        labels_list.append(label_val)
        adj_features.append(adj_feature)

        acc_list.append(acc)
        f_score_list.append(f_score)
        cm_list.append(cm)

    avg_acc = np.array(acc_list).mean()
    avg_f_score = np.array(f_score_list).mean()
    conf_matrix = np.array(cm_list).mean(axis=0)
    feature = torch.cat(features, dim=0)
    adj_feature = torch.cat(adj_features, dim=0)
    adj_feature = adj_feature.sum(dim=0)
    lable_feature = torch.cat(labels_list, dim=0)
    return fold_models, avg_acc, avg_f_score, conf_matrix, feature,adj_feature, lable_feature


def subject_dependent_exp():
    print('------------------------------------------------')
    print('|         subject dependent experiment         |')
    print('------------------------------------------------')

    params['K'] = 2
    logging.info(f'K: {params["K"]}')
    params['num_cells'] = 30
    params['e'] = 0.1
    params['lr'] = 0.0003
    logging.info(f'lr: {params["lr"]}')
    params['alpha'] = 0.0008

    dataset = SEED3Dataset('E:\\code\\GCN\\FCLGCN1\\FCLGCN\\data\\seed')
    avg_acc_list = []
    avg_f_score_list = []
    avg_cm_list = []

    acc_arrays = []
    f_score_arrays = []
    cm_arrays = []

    for seed in seeds:
        acc_list = []
        f_score_list = []
        cm_list = []

        step = 1
        for data, label in dataset:
            label = torch.from_numpy(label)
            used_label = label.reshape(-1).long()
            logging.info(f'-------seed {seed}, subject {step}-------')


            model_path = model_dir + '/' + f'seed{seed}/model_{step}.pt'
            if os.path.exists(model_path):
                logging.info('model already exists, loading...')
                trained_models, acc, f_score, cm, _,_, _ = torch.load(model_path)
                logging.info('model loaded.')
            else:
                trained_models, acc, f_score, cm, feature,adj_feature, labels_feature = cross_validation(data, used_label, seed)
                torch.save([trained_models, acc, f_score, cm, feature,adj_feature, labels_feature], model_path)
                logging.info('model trained.')

            acc_list.append(acc)
            f_score_list.append(f_score)
            cm_list.append(cm)
            # print(f'avg_acc: {acc}, avg_f_score: {f_score}')
            logging.info(f'avg_acc: {acc}, avg_f_score: {f_score}')

            step += 1

        acc_array = np.array(acc_list)
        f_score_array = np.array(f_score_list)
        cm_array = np.array(cm_list)
        img_path = img_dir + '/' + f'seed{seed}/dependent.png'
        # import pdb
        # pdb.set_trace()
        output_figure(img_path, acc_array, f_score_array, f'SEED')

        acc_arrays.append(acc_array)
        f_score_arrays.append(f_score_array)
        cm_arrays.append(cm_array)

    # calculate the average Acc and F-score of 3 seeds
    avg_acc = sum(acc_arrays) / len(acc_arrays)
    avg_acc_list.append(avg_acc)

    avg_f_score = sum(f_score_arrays) / len(f_score_arrays)
    avg_f_score_list.append(avg_f_score)

    np.save(model_dir+'for_tsne.npy', cm_arrays)
    output_figure(img_dir + '/' +f'/for_tsne.png', avg_acc, avg_f_score, f'SEED_avg')

    logging.info('-------------------RESULT-------------------')
    logging.info(f'    acc: {avg_acc_list}')
    logging.info(f'    f-score: {avg_f_score_list}')
    logging.info(f'    avg_acc = {np.mean(avg_acc_list)}, avg_f_score = {np.mean(avg_f_score_list)}')


if __name__ == '__main__':

    set_logger(log_path='./logs/seed/{}.log'.format(model_dir.split('/')[-1]))
    logging.basicConfig(format='%(asctime)s %(message)s', level=logging.INFO)
    subject_dependent_exp()