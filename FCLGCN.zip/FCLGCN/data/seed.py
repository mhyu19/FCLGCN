import _pickle as cPickle
import numpy as np
import torch
import os
from scipy.stats import pearsonr
from scipy.io import loadmat
from scipy.signal import stft
from torch_geometric.data import Data
from torch_geometric.data import Dataset
from torch_geometric.loader import DataLoader
from torch_geometric.data import Batch
import torch.nn.functional as F


fs = 200 # 采样频率


def load_data(data_path):
    """
    加载数据
    :param data_path: 数据路径
    :return: 数据
    """
    data = np.load(data_path)
    return data


def label_encode(labels):
    """
    标签编码
    :param labels: 标签
    :return: 编码后的标签
    """
    for i in range(len(labels)):
        if labels[i] == -1:
            labels[i] = 2
        elif labels[i] == 0:
            labels[i] = 0
        elif labels[i] == 1:
            labels[i] = 1
    labels = labels.squeeze()
    return labels


def data_divide(data, label):
    """
    数据分割
    :param label: shape[15,1]
    :param data: [15, 62, 37001]  [53001]
    :return: 分割后的数据和标签
    """
    window_size = 6  # 窗口大小
    step = 3  # 窗口滑动的步长
    point = data.shape[2]
    num = ((point // fs) - window_size) // step + 1  # 分割成的段数, 29段
    divided_data = []
    for i in range(0, num * step, step):
        segment = data[:, :, i * fs: (i + window_size) * fs]
        divided_data.append(segment)
    divided_data = np.vstack(divided_data)
    divided_label = np.vstack([label] * num)
    return divided_data, divided_label


def feature_extract(data_array):
    """
    提取特征
    :param data_array: 标定、分割过后的数据
    :return: 特征立方体
    """
    f, t, zxx = stft(data_array, fs=200, window='hann', nperseg=200, noverlap=0, nfft=400, scaling='psd')

    power = np.power(np.abs(zxx), 2)

    fStart = [0.5,4,8,14,31]  # 起始频率
    fEnd = [3,7,13,30,50]  # 终止频率

    de_time = []
    for i in range(1, len(t)):
        bands = []
        for j in range(len(fStart)):
            index1 = np.where(f == fStart[j])[0][0]
            index2 = np.where(f == fEnd[j])[0][0]
            psd = np.sum(power[:, :, index1:index2, i], axis=2) / (fEnd[j] - fStart[j] + 1)
            de = np.log2(psd)
            bands.append(de)
        de_bands = np.stack(bands, axis=-1)
        de_time.append(de_bands)
    de_features = np.stack(de_time, axis=1)
    # import pdb;pdb.set_trace()
    # shape : [num_samples, time, num_channels, band]
    return de_features


def to_graph(data):
    """
    将数据转化为图结构
    :param data: 数据 [B, T, N, D], B：sample numbers, D: num of Freq Band
    :return: Data 类型的图数据
    """
    graph_list = []
    for i in range(data.shape[0]):
        video_graph = []
        for time_data in data[i]:
            # edge_index, edge_attr = get_edge(torch.tensor(time_data))
            graph = Data(x=torch.tensor(time_data, dtype=torch.float32))
                         # edge_index=torch.tensor(edge_index, dtype=torch.int64).t().contiguous(),
                         # edge_attr=torch.tensor(edge_attr, dtype=torch.float32))
            video_graph.append(graph)
        batch = Batch.from_data_list(video_graph)
        graph_list.append(batch)
        # import pdb
        # pdb.set_trace()
    return graph_list

def get_edge(data):
    """
    计算数据邻接矩阵，边和权重
    :param data: (N, D) N节点数， D节点维度
    :return: 边顶点和边权重
    """
    num_nodes = data.shape[0]
    edge_index = []
    weights = []
    for i in range(num_nodes):
        # corr_list = torch.empty(num_nodes)
        for j in range(i + 1, num_nodes):
            corr = pearsonr(data[i], data[j])[0]
            # corr_list[j] = corr
            if corr > 0 and [i, j] not in edge_index:
                edge_index.append([i, j])
                edge_index.append([j, i])
                weights.append(corr)
                weights.append(corr)
    return edge_index, weights

def data_processing(data, label):
    """
    数据处理
    :param data: 数据
    :param label: 标签
    :return: 处理后的数据和标签
    """
    # 数据分割
    labels = label_encode(label)
    divide_data, labels = data_divide(data, labels)
    order_labels = labels.flatten(order='C')
    # print(data.shape)  # (760, 62, 2400)
    # 打标签
    # labels = set_label(labels)
    # 特征提取
    de_feature = feature_extract(divide_data)
    # import pdb;pdb.set_trace()
    # 转换为图结构
    graph_list = to_graph(de_feature)
    return graph_list, order_labels


class SEED3Dataset(Dataset):
    def __init__(self, root):
        super().__init__(root)

    @property
    def raw_file_names(self):
        return os.listdir(self.raw_dir)

    @property
    def processed_file_names(self):
        file_names = []
        for file_name in self.raw_file_names:
            root, ext = os.path.splitext(file_name)
            file_names.append(root + '.pt')
        return file_names

    def download(self):
        pass

    def process(self):
        for i in range(len(self.raw_paths)):
            print('processing:',self.raw_paths[i])
            x = loadmat(self.raw_paths[i])
            processed_data = data_processing(x['data'], x['label'])
            torch.save(processed_data, self.processed_paths[i])

    def get(self, index):
        print(self.processed_paths[index])
        data = torch.load(self.processed_paths[index])
        return data

    def len(self):
        return len(self.raw_file_names)


if __name__ == '__main__':
    data_path = '/data/seed/'
    SEED3Data = SEED3Dataset(data_path)
    for data, label in SEED3Data:
        # print(data.shape)
        print(label.shape)
