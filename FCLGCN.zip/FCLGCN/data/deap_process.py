import numpy as np
import torch
import os
import _pickle as cPickle
from scipy.signal import stft
import scipy.io as sio
from torch_geometric.data import Dataset
from torch_geometric.data import Batch, Data
from torch_geometric.loader import DataLoader
from scipy.stats import pearsonr
from torch_geometric.nn import ChebConv, GCNConv, GATConv

fs = 128


def label_process(labels):
    """
    打标签
    :param labels: 标签
    :return: 处理后的标签
    """
    return torch.tensor(np.where(labels < 5, 0, 1), dtype=torch.long)  # 小于 5 的元素改为 0，大于等于 5 的改为 1


def extract_feature(data, fs=128):
    """
    提取特征
    :param np.ndarray data: 分割后的数据 每个受试者：[240, 32, 1280]
    :param fs: 采样频率
    :return: 特征
    """
    # 短时傅里叶变换
    f, t, zxx = stft(data, fs=fs, window='hann', nperseg=128, noverlap=0, nfft=256, scaling='psd')
    # f, t 的长度与数据最后一位有关
    power = np.power(np.abs(zxx), 2)
    fStart = [1, 4, 8, 14, 31]  # 起始频率
    fEnd = [4, 8, 14, 31, 50]  # 终止频率
    # 计算特征
    de_time = []
    for i in range(1, len(t)):
        bands = []
        for j in range(len(fStart)):
            index1 = np.where(f == fStart[j])[0][0]
            index2 = np.where(f == fEnd[j])[0][0]
            psd = np.sum(power[:, :, index1:index2, i], axis=2) / (fEnd[j] - fStart[j] + 1)
            de = np.log2(psd)
            bands.append(de)
        de_bands = np.stack(bands, axis=-1)
        de_time.append(de_bands)
    de_features = np.stack(de_time, axis=1)
    return de_features


def data_divided(raw_data, label):
    window_size = 6  # 6s时间窗口
    step = 3  # 3s步长 有重叠
    num = (60 - window_size) // step + 1  # 分割段数
    # 校准数据，前3秒数据分割
    baseline_time = 3
    _, real_data = np.split(raw_data, [baseline_time * fs], axis=-1)
    # real_data: [40, 32, 7680]
    # 数据分割
    data_divided = []
    for i in range(0, num * step, step):
        segment = real_data[:, :, i * fs:(i + window_size) * fs]  # [40, 32, 6s*fs]
        data_divided.append(segment)
    data_divided = np.vstack(data_divided)  # [40*num, 32, 6s*fs] [760, 32, 768]
    label_divided = np.vstack([label]*num)  # [40*num, 4]         [760, 4]
    return data_divided, label_divided


def split_data(raw_data, label):
    baseline_time = 3
    _, real_data = np.split(raw_data, [baseline_time * fs], axis=-1)
    window_size = 10
    num_time_step = 6
    split = []
    for i in range(0, num_time_step):
        segment = real_data[:, :, i * 128:(i + 10) * 128]
        split.append(segment)
    data_split = np.vstack(split)
    # label_split = np.vstack([label] * num_time_step)
    return data_split, label


def to_graph(data):
    """
    将数据转化为图结构
    :param data: 数据 [B, N, F, D], B：sample numbers, F: Freq Bands
    :return: Data 类型的图数据
    """
    graph_list = []
    for i in range(data.shape[0]):
        video_graph = []
        for time_data in data[i]:
            # edge_index, edge_attr = get_edge(torch.tensor(time_data))
            graph = Data(x=torch.tensor(time_data, dtype=torch.float32))
                         # edge_index=torch.tensor(edge_index, dtype=torch.int64).t().contiguous(),
                         # edge_attr=torch.tensor(edge_attr, dtype=torch.float32))
            video_graph.append(graph)
        batch = Batch.from_data_list(video_graph)
        graph_list.append(batch)
    return graph_list


def get_edge(data):
    """
    计算数据邻接矩阵，边和权重
    :param data: (N, D) N节点数， D节点维度
    :return: 边顶点和边权重
    """
    num_nodes = data.shape[0]
    edge_index = []
    weights = []
    for i in range(num_nodes):
        # corr_list = torch.empty(num_nodes)
        for j in range(i + 1, num_nodes):
            corr = pearsonr(data[i], data[j])[0]
            # corr_list[j] = corr
            if corr > 0 and [i, j] not in edge_index:
                edge_index.append([i, j])
                edge_index.append([j, i])
                weights.append(corr)
                weights.append(corr)
    return edge_index, weights


def get_edge_full(data):
    """
    计算数据邻接矩阵，边和权重
    :param data: (N, D) N节点数， D节点维度
    :return: 边顶点和边权重
    """
    num_nodes = data.shape[0]
    edge_index = []
    weights = []
    for i in range(num_nodes):
        # corr_list = torch.empty(num_nodes)
        for j in range(i + 1, num_nodes):
            corr = pearsonr(data[i], data[j])[0]
            # corr_list[j] = corr
            if [i, j] not in edge_index:
                edge_index.append([i, j])
                edge_index.append([j, i])
                weights.append(corr)
                weights.append(corr)
    return edge_index, weights


def data_process(data, labels):
    data, labels = data_divided(data[:, :32, :], labels)
    labels = label_process(labels)
    de_features = extract_feature(data)
    graph_list = to_graph(de_features)
    return graph_list, labels


class DeapDataset(Dataset):
    def __init__(self, root):
        super().__init__(root)

    @property
    def raw_file_names(self):

        return os.listdir(self.raw_dir)

    @property
    def processed_file_names(self):
        file_names = []
        for file_name in self.raw_file_names:
            # print(file_name)
            root, ext = os.path.splitext(file_name)
            file_names.append(root + '.pt')
        return file_names

    def download(self):
        pass

    def process(self):
        for i in range(len(self.raw_paths)):
            with open(self.raw_paths[i], 'rb') as f:
                x = cPickle.load(f, encoding='iso-8859-1')
            processed_data = data_process(x['data'], x['labels'])
            # import pdb
            # pdb.set_trace()
            torch.save(processed_data, self.processed_paths[i])

    def get(self, index):
        data = torch.load(self.processed_paths[index])
        return data

    def len(self):
        return len(self.raw_file_names)


if __name__ == '__main__':

    DEAPData = DeapDataset('./data/DEAP/data_preprocessed_python/')
    dataset, labels = DEAPData[0]
    # import pdb
    # pdb.set_trace()
    data_loder = DataLoader(DEAPData, batch_size=1, shuffle=False)
    for data, labels in data_loder:
        print(len(data))
        # print(data)
        print(labels)
        break
